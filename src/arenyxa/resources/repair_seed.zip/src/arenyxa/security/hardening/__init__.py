"""Additional v8.0 security hardening utilities."""
