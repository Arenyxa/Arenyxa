"""Arenyxa cryptographic hardening layer."""
