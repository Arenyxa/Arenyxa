from __future__ import annotations

import argparse
import json
import os
import queue
import threading
import time
from collections import Counter
from pathlib import Path
from typing import Any

import psycopg

import variance_observer as vo
from scripts import postgresql_32_worker_gate as gate


class CycleTracer:
    def __init__(self) -> None:
        self.active = False
        self.run_no = 0
        self.local = threading.local()
        self.lock = threading.Lock()
        self.cycles: list[dict[str, Any]] = []
        self._lease = gate.DurableDistributedQueue.lease_next
        self._start = gate.DurableDistributedQueue.start_job
        self._complete = gate.DurableDistributedQueue.complete

    def install(self) -> None:
        owner = self
        orig_lease, orig_start, orig_complete = self._lease, self._start, self._complete

        def lease_next(obj, worker_id, *args, **kwargs):
            begin_mono, begin_wall = time.monotonic(), time.time()
            result = orig_lease(obj, worker_id, *args, **kwargs)
            if owner.active and result is not None:
                owner.local.current = {
                    "run": owner.run_no, "worker_id": str(worker_id), "job_id": str(result.job_id),
                    "cycle_start_mono": begin_mono, "cycle_start_wall": begin_wall,
                    "lease_start_mono": begin_mono, "lease_end_mono": time.monotonic(),
                }
            return result

        def start_job(obj, job_id, worker_id, lease_token, *args, **kwargs):
            cur = getattr(owner.local, "current", None)
            t0 = time.monotonic()
            try:
                return orig_start(obj, job_id, worker_id, lease_token, *args, **kwargs)
            finally:
                if owner.active and cur is not None and cur.get("job_id") == str(job_id):
                    cur["start_start_mono"] = t0
                    cur["start_end_mono"] = time.monotonic()

        def complete(obj, job_id, worker_id, lease_token, result, *args, **kwargs):
            cur = getattr(owner.local, "current", None)
            t0 = time.monotonic()
            try:
                return orig_complete(obj, job_id, worker_id, lease_token, result, *args, **kwargs)
            finally:
                if owner.active and cur is not None and cur.get("job_id") == str(job_id):
                    t1 = time.monotonic()
                    cur["complete_start_mono"] = t0
                    cur["complete_end_mono"] = t1
                    cur["cycle_end_mono"] = t1
                    cur["cycle_end_wall"] = time.time()
                    cur["cycle_ms"] = (t1 - cur["cycle_start_mono"]) * 1000.0
                    cur["lease_ms"] = (cur["lease_end_mono"] - cur["lease_start_mono"]) * 1000.0
                    if "start_end_mono" in cur:
                        cur["start_ms"] = (cur["start_end_mono"] - cur["start_start_mono"]) * 1000.0
                    cur["complete_ms"] = (t1 - t0) * 1000.0
                    with owner.lock:
                        owner.cycles.append(dict(cur))
                    owner.local.current = None

        gate.DurableDistributedQueue.lease_next = lease_next
        gate.DurableDistributedQueue.start_job = start_job
        gate.DurableDistributedQueue.complete = complete

    def restore(self) -> None:
        gate.DurableDistributedQueue.lease_next = self._lease
        gate.DurableDistributedQueue.start_job = self._start
        gate.DurableDistributedQueue.complete = self._complete


class MaintenanceObserver:
    def __init__(self, dsn: str, interval_s: float = 0.1) -> None:
        self.dsn = dsn
        self.interval_s = interval_s
        self.stop = threading.Event()
        self.samples: list[dict[str, Any]] = []
        self.errors: list[str] = []
        self.thread = threading.Thread(target=self._run, name="phase2-maintenance-observer", daemon=True)

    def start(self) -> None:
        self.thread.start()

    def close(self) -> None:
        self.stop.set()
        self.thread.join(timeout=10.0)

    def _run(self) -> None:
        try:
            with psycopg.connect(self.dsn, autocommit=True, application_name="arenyxa-phase2-maintenance") as conn:
                observer_pid = conn.info.backend_pid
                while not self.stop.wait(self.interval_s):
                    mono, wall = time.monotonic(), time.time()
                    activity = []
                    rows = conn.execute(
                        """
                        SELECT pid,backend_type,state,COALESCE(wait_event_type,''),COALESCE(wait_event,''),
                               COALESCE(query,''),query_start
                        FROM pg_stat_activity
                        WHERE datname=current_database() AND pid<>%s
                          AND (backend_type='autovacuum worker' OR query ILIKE 'autovacuum:%%' OR query ILIKE '%%analyze%%')
                        """,
                        (observer_pid,),
                    ).fetchall()
                    for pid, backend_type, state, wet, we, query_text, query_start in rows:
                        activity.append({
                            "pid": int(pid), "backend_type": str(backend_type), "state": str(state),
                            "wait_event_type": str(wet), "wait_event": str(we),
                            "query": str(query_text)[:500], "query_start": None if query_start is None else str(query_start),
                        })
                    progress = []
                    for row in conn.execute(
                        """
                        SELECT p.pid,c.relname,p.phase,p.heap_blks_total,p.heap_blks_scanned,p.heap_blks_vacuumed,
                               p.index_vacuum_count,p.max_dead_tuples,p.num_dead_tuples
                        FROM pg_stat_progress_vacuum p
                        LEFT JOIN pg_class c ON c.oid=p.relid
                        """
                    ).fetchall():
                        progress.append({
                            "pid": int(row[0]), "relation": None if row[1] is None else str(row[1]), "phase": str(row[2]),
                            "heap_blks_total": int(row[3] or 0), "heap_blks_scanned": int(row[4] or 0),
                            "heap_blks_vacuumed": int(row[5] or 0), "index_vacuum_count": int(row[6] or 0),
                            "max_dead_tuples": int(row[7] or 0), "num_dead_tuples": int(row[8] or 0),
                        })
                    if activity or progress:
                        self.samples.append({"mono": mono, "wall": wall, "activity": activity, "progress": progress})
        except BaseException as exc:
            self.errors.append(f"{type(exc).__name__}:{exc}")


def user_table_maintenance(conn: psycopg.Connection[Any]) -> dict[str, Any]:
    conn.execute("SELECT pg_stat_clear_snapshot()")
    out = {}
    for row in conn.execute(
        """
        SELECT relname,autovacuum_count,autoanalyze_count,last_autovacuum,last_autoanalyze
        FROM pg_stat_user_tables WHERE relname LIKE 'distributed_%' ORDER BY relname
        """
    ).fetchall():
        out[str(row[0])] = {
            "autovacuum_count": int(row[1] or 0), "autoanalyze_count": int(row[2] or 0),
            "last_autovacuum": None if row[3] is None else str(row[3]),
            "last_autoanalyze": None if row[4] is None else str(row[4]),
        }
    return out


def maintenance_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    out = {}
    for rel, a in after.items():
        b = before.get(rel, {})
        dv = int(a.get("autovacuum_count", 0)) - int(b.get("autovacuum_count", 0))
        da = int(a.get("autoanalyze_count", 0)) - int(b.get("autoanalyze_count", 0))
        if dv or da:
            out[rel] = {"autovacuum": dv, "autoanalyze": da, "after": a}
    return out


class GateWindow:
    def __init__(self, original: type[Any], tracer: CycleTracer) -> None:
        self.original = original
        self.tracer = tracer
        self.start_mono: float | None = None
        self.end_mono: float | None = None

    def make(self) -> type[Any]:
        owner = self
        original = self.original
        class DiagnosticExecutor(original):
            def __enter__(self):
                owner.start_mono = time.monotonic()
                owner.tracer.active = True
                return super().__enter__()
            def __exit__(self, exc_type, exc, tb):
                try:
                    return super().__exit__(exc_type, exc, tb)
                finally:
                    owner.tracer.active = False
                    owner.end_mono = time.monotonic()
        return DiagnosticExecutor


def intervals(samples: list[dict[str, Any]], interval_s: float) -> list[dict[str, Any]]:
    grouped: dict[tuple[int, str], list[dict[str, Any]]] = {}
    for sample in samples:
        for row in sample.get("activity", []):
            key = (int(row["pid"]), str(row.get("query") or row.get("backend_type")))
            grouped.setdefault(key, []).append({"mono": sample["mono"], **row})
    out = []
    for (pid, query_text), rows in grouped.items():
        rows.sort(key=lambda x: x["mono"])
        start = rows[0]["mono"] - interval_s / 2
        last = rows[0]["mono"]
        bucket = [rows[0]]
        for row in rows[1:]:
            if row["mono"] - last > interval_s * 2.5:
                out.append({"pid": pid, "query": query_text, "start_mono": start, "end_mono": last + interval_s / 2, "samples": bucket})
                start, bucket = row["mono"] - interval_s / 2, [row]
            else:
                bucket.append(row)
            last = row["mono"]
        out.append({"pid": pid, "query": query_text, "start_mono": start, "end_mono": last + interval_s / 2, "samples": bucket})
    return out


def overlap(cycle: dict[str, Any], maint: dict[str, Any]) -> bool:
    return cycle["cycle_start_mono"] <= maint["end_mono"] and cycle["cycle_end_mono"] >= maint["start_mono"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--runs", type=int, default=20)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    tracer = CycleTracer()
    tracer.install()
    observer = MaintenanceObserver(args.dsn, 0.1)
    observer.start()
    rows = []
    original_executor = gate.ThreadPoolExecutor
    try:
        with psycopg.connect(args.dsn, autocommit=True, application_name="arenyxa-phase2-maintenance-snapshot") as conn:
            for run_no in range(1, args.runs + 1):
                tracer.run_no = run_no
                before = user_table_maintenance(conn)
                window = GateWindow(original_executor, tracer)
                gate.ThreadPoolExecutor = window.make()
                try:
                    result = gate.run_gate(args.dsn, workers=64, concurrency=128, jobs=1024, p99_budget_ms=500.0)
                finally:
                    gate.ThreadPoolExecutor = original_executor
                after = user_table_maintenance(conn)
                row = {
                    "run": run_no,
                    "result": result,
                    "correctness_pass": vo.correctness(result),
                    "window": {"start_mono": window.start_mono, "end_mono": window.end_mono},
                    "maintenance_delta": maintenance_delta(before, after),
                }
                rows.append(row)
                print(json.dumps({
                    "run": run_no, "p99": result["latency_ms"]["p99"],
                    "maintenance_delta": row["maintenance_delta"], "correctness": row["correctness_pass"],
                }, sort_keys=True), flush=True)
    finally:
        gate.ThreadPoolExecutor = original_executor
        observer.close()
        tracer.restore()

    maint_intervals = intervals(observer.samples, observer.interval_s)
    cycles = list(tracer.cycles)
    for cycle in cycles:
        overlaps = [m for m in maint_intervals if overlap(cycle, m)]
        cycle["maintenance_overlap"] = bool(overlaps)
        cycle["maintenance_pids"] = sorted({int(m["pid"]) for m in overlaps})
        cycle["maintenance_queries"] = sorted({str(m["query"])[:300] for m in overlaps})
    by_run: dict[int, list[dict[str, Any]]] = {}
    for cycle in cycles:
        by_run.setdefault(int(cycle["run"]), []).append(cycle)
    top20 = {}
    for run_no, values in by_run.items():
        top20[str(run_no)] = sorted(values, key=lambda x: float(x.get("cycle_ms", 0.0)), reverse=True)[:20]
    warm_cycles = [x for x in cycles if int(x["run"]) >= 2]
    global_top20 = sorted(warm_cycles, key=lambda x: float(x.get("cycle_ms", 0.0)), reverse=True)[:20]
    summary = {
        "schema": "arenyxa.phase2-maintenance-trace/v1",
        "runs": rows,
        "observer_errors": observer.errors,
        "maintenance_intervals": maint_intervals,
        "cycle_count": len(cycles),
        "top20_by_run": top20,
        "global_warm_top20": global_top20,
        "warm_top20_overlap_count": sum(1 for x in global_top20 if x.get("maintenance_overlap")),
        "warm_top20_count": len(global_top20),
        "all_correctness_pass": all(x["correctness_pass"] for x in rows),
    }
    (args.out / "maintenance-trace-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, default=str), encoding="utf-8")
    (args.out / "maintenance-samples.json").write_text(json.dumps(observer.samples, separators=(",", ":"), default=str), encoding="utf-8")
    (args.out / "cycle-traces.json").write_text(json.dumps(cycles, separators=(",", ":"), default=str), encoding="utf-8")
    if observer.errors or not summary["all_correctness_pass"]:
        return 5
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
