from __future__ import annotations

import argparse
import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import psycopg
from psycopg.conninfo import conninfo_to_dict, make_conninfo


def fresh_database(base_dsn: str, label: str) -> str:
    info = conninfo_to_dict(base_dsn)
    admin = dict(info)
    admin["dbname"] = "postgres"
    suffix = f"{int(time.time()*1000)%10_000_000}_{os.getpid()}"
    dbname = f"phase2_{label}_{suffix}".lower()
    with psycopg.connect(make_conninfo(**admin), autocommit=True) as conn:
        conn.execute(f'CREATE DATABASE "{dbname}"')
    target = dict(info)
    target["dbname"] = dbname
    return make_conninfo(**target)


def run_script(script: Path, dsn: str, mode: str, output: Path, module_list: Path | None = None) -> dict[str, Any]:
    cmd = [sys.executable, str(script), "--dsn", dsn, "--mode", mode, "--output", str(output)]
    if module_list is not None:
        cmd += ["--module-list", str(module_list)]
    subprocess.run(cmd, check=True, env={**os.environ, "PYTHONPATH": os.environ.get("GITHUB_WORKSPACE", os.getcwd())})
    return json.loads(output.read_text(encoding="utf-8"))


def metric(row: dict[str, Any], key: str) -> Any:
    result = row["result"]
    dist = row["full_distributions"]
    mapping = {
        "p50": result["latency_ms"]["p50"], "p95": result["latency_ms"]["p95"],
        "p99": result["latency_ms"]["p99"], "p999": dist["cycle"]["p999"], "max": result["latency_ms"]["max"],
        "lease_p99": result["latency_ms"]["phases"]["lease_next"]["p99"],
        "start_p99": result["latency_ms"]["phases"]["start_job"]["p99"],
        "complete_p99": result["latency_ms"]["phases"]["complete"]["p99"],
        "gate_throughput": result["throughput_jobs_per_second"],
        "diagnostic_throughput": row["threadpool_window"]["diagnostic_throughput_jobs_per_second"],
    }
    return mapping[key]


def compact(label: str, row: dict[str, Any]) -> dict[str, Any]:
    return {
        "experiment": label,
        **{k: metric(row, k) for k in ("p50", "p95", "p99", "p999", "max", "lease_p99", "start_p99", "complete_p99", "gate_throughput", "diagnostic_throughput")},
        "timed_db_reads": row["timed_pg_delta"]["database"].get("blks_read"),
        "timed_db_hits": row["timed_pg_delta"]["database"].get("blks_hit"),
        "timed_wal_bytes": row["timed_pg_delta"]["wal"].get("wal_bytes"),
        "timed_wal_fpi": row["timed_pg_delta"]["wal"].get("wal_fpi"),
        "timed_modules_loaded": row["timed_runtime_delta"]["module_count"],
        "timed_minor_faults": row["timed_runtime_delta"]["minor_faults"],
        "timed_major_faults": row["timed_runtime_delta"]["major_faults"],
        "timed_rss_delta": row["timed_runtime_delta"]["rss"],
        "thread_start_count": row["thread_startup_summary"]["count"],
        "thread_start_last_ms": row["thread_startup_summary"]["last_offset_ms"],
        "runq_avg": row["scheduler"]["runnable"]["mean"],
        "runq_peak": row["scheduler"]["runnable"]["max"],
        "cpu_avg": row["scheduler"]["cpu_total_percent"]["mean"],
        "postgres_cpu_avg": row["scheduler"]["postgres_cpu_percent"]["mean"],
        "python_cpu_avg": row["scheduler"]["python_cpu_percent"]["mean"],
        "active_backends_avg": row["scheduler"]["active_backend_count"]["mean"],
        "lock_wait_samples": sum(row["scheduler"]["lock_wait_weighted_samples"].values()),
        "wal_wait_samples": sum(row["scheduler"]["wal_wait_weighted_samples"].values()),
        "pool_wait_ms": row["pool_summary"]["wait_ms_total"],
        "correctness": row["correctness_pass"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dsn", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    script = Path(__file__).with_name("timed_state_isolation.py")

    dsns = {name: fresh_database(args.dsn, name) for name in ("a0", "a1", "a2", "a3")}

    # A0: fresh DB + fresh runtime. Run first to preserve the coldest host-local state available in this job.
    a0 = run_script(script, dsns["a0"], "measure-fresh", args.out / "A0.json")
    module_list = args.out / "a0-timed-modules.json"
    module_list.write_text(json.dumps(a0["timed_runtime_delta"]["modules_loaded"], indent=2), encoding="utf-8")

    # A2 second: fresh untouched DB, but explicitly precondition runtime in the measured process.
    a2 = run_script(script, dsns["a2"], "measure-runtime-warm", args.out / "A2.json", module_list)

    # A1: use a separate process to warm the DB, then a fresh measured Python process.
    run_script(script, dsns["a1"], "warmup-db", args.out / "A1_db_warmup.json")
    a1 = run_script(script, dsns["a1"], "measure-fresh", args.out / "A1.json")

    # A3: DB preconditioned by a separate process + runtime preconditioned in the measured process.
    run_script(script, dsns["a3"], "warmup-db", args.out / "A3_db_warmup.json")
    a3 = run_script(script, dsns["a3"], "measure-runtime-warm", args.out / "A3.json", module_list)

    rows = {"A0": a0, "A1": a1, "A2": a2, "A3": a3}
    summary = {
        "schema": "arenyxa.phase2-state-isolation/v1",
        "order": ["A0", "A2", "A1", "A3"],
        "experiments": [compact(label, rows[label]) for label in ("A0", "A1", "A2", "A3")],
        "notes": {
            "A0": "fresh database + fresh measured Python process",
            "A1": "database preconditioned by one full diagnostic gate in a separate process; measured process fresh",
            "A2": "fresh database; measured process runtime-preconditioned without PostgreSQL access",
            "A3": "database preconditioned by one full diagnostic gate in a separate process; measured process runtime-preconditioned",
            "important": "Dedicated databases isolate relation state, but all four conditions share one host and one PostgreSQL cluster/OS page-cache domain.",
        },
    }
    (args.out / "state-isolation-summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, default=str), encoding="utf-8")
    print(json.dumps(summary, sort_keys=True), flush=True)
    return 0 if all(x["correctness_pass"] for x in rows.values()) else 4


if __name__ == "__main__":
    raise SystemExit(main())
